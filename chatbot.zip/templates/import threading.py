import threading
import time

lock1 = threading.Lock()
lock2 = threading.Lock()

def thread1():
    print("Thread 1: Acquiring Lock 1")
    lock1.acquire()
    print("Thread 1: Acquired Lock 1")
    time.sleep(2)
    print("Thread 1: Trying to acquire Lock 2")
    lock2.acquire()
    print("Thread 1: Acquired Lock 2")
    time.sleep(1)
    lock2.release()
    lock1.release()
    print("Thread 1: Finished work")

def thread2():
    print("Thread 2: Acquiring Lock 2")
    lock2.acquire()
    print("Thread 2: Acquired Lock 2")
    time.sleep(2)
    print("Thread 2: Trying to acquire Lock 1")
    lock1.acquire()
    print("Thread 2: Acquired Lock 1")
    time.sleep(1)
    lock1.release()
    lock2.release()
    print("Thread 2: Finished work")

t1 = threading.Thread(target=thread1)
t2 = threading.Thread(target=thread2)

t1.start()
t2.start()

# Deadlock detection logic
start_time = time.time()
while True:
    if not t1.is_alive() and not t2.is_alive():
        print("Both threads completed.")
        break
    if time.time() - start_time > 10:
        print("Deadlock detected! Threads are stuck.")
        break
    time.sleep(1)
